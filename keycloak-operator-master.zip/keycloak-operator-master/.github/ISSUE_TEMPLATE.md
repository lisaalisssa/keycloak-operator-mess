## Description
<!-- Add a brief and meaningful description. -->

## Expected Behavior
<!-- Describe the expected behaviour. -->

## Actual Behavior
<!-- Describe the current/actual behaviour. -->

## Environment
* OpenShift or Kubernetes version:
<!-- Run the command `oc version` and add the result here. -->
* Project Version/Tag: (E.g release-1.0.1)

## Steps to reproduce
<!-- Describe all steps and pre-requirements which are required to be performed in order to reproduce this scenario. ( E.g 1. Action, 2. Action ... ) -->