// Package v1alpha1 contains API Schema definitions for the keycloak v1alpha1 API group
// +k8s:deepcopy-gen=package,register
// +groupName=keycloak.org
package v1alpha1
